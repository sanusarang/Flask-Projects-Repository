from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Sample in-memory storage for diary entries
# Each entry will be a dictionary with id, title, content, and date
diary_entries = []

# Home route - display all entries
@app.route('/')
def index():
    return render_template('index.html', entries=diary_entries)

# Route to add a new entry
@app.route('/add', methods=['GET', 'POST'])
def add_entry():
    if request.method == 'POST':
        title = request.form.get('title')
        content = request.form.get('content')
        diary_entries.append({
            "id": len(diary_entries) + 1,
            "title": title,
            "content": content,
        })
        return redirect(url_for('index'))
    return render_template('add.html')

# Route to view a single entry
@app.route('/view/<int:entry_id>')
def view_entry(entry_id):
    entry = next((e for e in diary_entries if e['id'] == entry_id), None)
    return render_template('view.html', entry=entry)

# Route to edit an entry
@app.route('/edit/<int:entry_id>', methods=['GET', 'POST'])
def edit_entry(entry_id):
    entry = next((e for e in diary_entries if e['id'] == entry_id), None)
    if request.method == 'POST':
        entry['title'] = request.form.get('title')
        entry['content'] = request.form.get('content')
        return redirect(url_for('index'))
    return render_template('edit.html', entry=entry)

# Route to delete an entry
@app.route('/delete/<int:entry_id>')
def delete_entry(entry_id):
    global diary_entries
    diary_entries = [e for e in diary_entries if e['id'] != entry_id]
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
